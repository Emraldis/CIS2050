#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "binTree.h"
#include "data.h"

/*Alpheaus Feltham, 0903594*/

int main (void){
	
	return(0);
}